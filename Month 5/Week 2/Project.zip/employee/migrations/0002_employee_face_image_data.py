# Generated for database-backed face comparison data.

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('employee', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='employee',
            name='face_image_data',
            field=models.BinaryField(blank=True, null=True),
        ),
    ]
