from django.db import migrations


def backfill_face_image_data(apps, schema_editor):
    Employee = apps.get_model('employee', 'Employee')

    for employee in Employee.objects.filter(face_image_data__isnull=True):
        if not employee.face_image:
            continue

        try:
            employee.face_image.open('rb')
            employee.face_image_data = employee.face_image.read()
            employee.face_image.close()
            employee.save(update_fields=['face_image_data'])
        except OSError:
            continue


class Migration(migrations.Migration):

    dependencies = [
        ('employee', '0002_employee_face_image_data'),
    ]

    operations = [
        migrations.RunPython(backfill_face_image_data, migrations.RunPython.noop),
    ]
