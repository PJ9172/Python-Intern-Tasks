from django.urls import path

from . import views

urlpatterns = [
    path('register/', views.register_page),
    path('save/', views.save_employee),
    path('login/', views.login_page),
    path('validate-login/', views.credential_check),
    path('dashboard/', views.dashboard),
    path('employee-face/<int:employee_id>/', views.employee_face),
]