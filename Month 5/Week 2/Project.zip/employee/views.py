import base64
import mimetypes
import os

from django.core.files.base import ContentFile
from django.contrib.auth.hashers import make_password, check_password

from rest_framework.decorators import api_view
from rest_framework.response import Response

from django.shortcuts import render

from .models import Employee


def dashboard(request):
    return render(request, 'dashboard.html')

def register_page(request):
    return render(request, 'register.html')

def login_page(request):
    return render(request, 'login.html', {
        'face_verify_url': os.getenv(
            'FACE_VERIFY_API_URL',
            'https://face-auth-project-fastapi.onrender.com/verify-face/'
        )
    })


# register employee
@api_view(['POST'])
def save_employee(request):

    try:

        data = request.data

        name = data.get("name")

        email = data.get("email")

        password = data.get("password")

        image_data = data.get("image")

        if not all([name, email, password, image_data]):
            return Response({
                "error": "Name, email, password, and face image are required"
            }, status=400)

        if Employee.objects.filter(email=email).exists():
            return Response({
                "error": "An employee with this email already exists"
            }, status=400)

        # Remove base64 header
        format, imgstr = image_data.split(';base64,')

        ext = format.split('/')[-1]

        image_bytes = base64.b64decode(imgstr)

        image_file = ContentFile(
            image_bytes,
            name=f"{name}.{ext}"
        )

        employee = Employee.objects.create(

            name=name,

            email=email,

            password=make_password(password),

            face_image_data=image_bytes
        )

        return Response({
            "message": "Employee Registered Successfully"
        })

    except Exception as e:

        return Response({
            "error": str(e)
        }, status=400)
    

# authenticate employee
@api_view(['POST'])
def credential_check(request):

    try:

        data = request.data

        email = data.get("email")

        password = data.get("password")

        image_data = data.get("image")

        if not email or not password:
            return Response({
                "message": "Email and password are required"
            }, status=400)

        # Find employee
        employee = Employee.objects.filter(
            email=email
        ).first()

        if not employee:

            return Response({
                "message": "Employee not found"
            }, status=404)

        # Check password
        if not check_password(password, employee.password):

            return Response({
                "message": "Invalid password"
            }, status=401)

        return Response({
            "success": True,
            "message": "Credentials verified",
            "employee_id": employee.id
        })

    except Exception as e:
        return Response({
            "error": str(e)
        }, status=400)


# get employee face image for verification

@api_view(['GET'])
def employee_face(request, employee_id):

    employee = Employee.objects.get(id=employee_id)

    image_bytes = employee.face_image_data

    database_image = base64.b64encode(image_bytes).decode()

    return Response({
        "image": database_image
    })