import base64
import cv2
import numpy as np
import os
import requests

from fastapi.middleware.cors import CORSMiddleware

from io import BytesIO

from PIL import Image

from fastapi import FastAPI
from pydantic import BaseModel

from deepface import DeepFace


app = FastAPI()

FACE_MODEL_NAME = os.getenv("FACE_MODEL_NAME", "SFace")
FACE_DETECTOR_BACKEND = os.getenv("FACE_DETECTOR_BACKEND", "opencv")
FACE_DISTANCE_METRIC = os.getenv("FACE_DISTANCE_METRIC", "cosine")

DeepFace.build_model(FACE_MODEL_NAME)

FACE_CASCADE = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)

app.add_middleware(

    CORSMiddleware,

    allow_origins=[
        origin.strip()
        for origin in os.getenv(
            "CORS_ALLOWED_ORIGINS",
            "https://face-auth-project-django.onrender.com"
        ).split(",")
        if origin.strip()
    ],

    allow_credentials=True,

    allow_methods=["*"],

    allow_headers=["*"],
)


class FrameData(BaseModel):
    image: str
    employee_id: int


def base64_to_numpy(base64_string):

    if "," in base64_string:
        _, encoded = base64_string.split(",", 1)
    else:
        encoded = base64_string

    image_data = base64.b64decode(encoded)

    image = Image.open(BytesIO(image_data))

    image_np = np.array(image)

    image_np = cv2.cvtColor(
        image_np,
        cv2.COLOR_RGB2BGR
    )

    return image_np


def detect_face_box(frame):

    if FACE_CASCADE.empty():
        return None

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    faces = FACE_CASCADE.detectMultiScale(
        gray,
        scaleFactor=1.1,
        minNeighbors=5,
        minSize=(80, 80)
    )

    if len(faces) == 0:
        return None

    x, y, w, h = max(
        faces,
        key=lambda face: face[2] * face[3]
    )

    return {
        "x": int(x),
        "y": int(y),
        "width": int(w),
        "height": int(h),
        "image_width": int(frame.shape[1]),
        "image_height": int(frame.shape[0])
    }


@app.post("/verify-face/")
async def verify_face(data: FrameData):

    try:

        # LIVE CAMERA IMAGE
        live_image = base64_to_numpy(data.image)

        # FACE BOX FROM LIVE FRAME
        face_box = detect_face_box(live_image)

        print("Detected face box:", face_box)

        # GET EMPLOYEE DATABASE IMAGE
        response = requests.get(
            f"https://face-auth-project-django.onrender.com/employee-face/{data.employee_id}/"
        )

        print("Employee image URL:", response.json().get("image"))


        employee_base64 = response.json()["image"]

        employee_image = base64_to_numpy(employee_base64)

        print("Employee image shape:", employee_image.shape)

        # FACE VERIFICATION
        result = DeepFace.verify(

            img1_path=live_image,

            img2_path=employee_image,

            model_name=FACE_MODEL_NAME,

            detector_backend=FACE_DETECTOR_BACKEND,

            distance_metric=FACE_DISTANCE_METRIC,

            enforce_detection=True,

            align=True
        )

        return {
            "verified": result["verified"],
            "distance": float(result["distance"]),
            "face_box": face_box
        }

    except Exception as e:

        return {
            "verified": False,
            "error": str(e),
            "face_box": None
        }

